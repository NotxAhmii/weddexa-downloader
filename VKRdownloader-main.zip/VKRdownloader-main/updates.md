# VKrDownloader Updates
<li> Fixed Instagram and tiktok downloading </li>
