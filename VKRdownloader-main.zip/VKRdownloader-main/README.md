# VKrDownloader 

Video Downloader by  Vijay Kumar @TheOfficialVKr ....

Download Video From
<li> YouTube </li> <li>  Facebook  </li> <li> Twitter  </li> <li> Instagram (reel)  </li> <li> TikTok  </li> <li>And  1000+ Other Website in All Audio / Video Quality ...
 </li>


# Check All Updates Here: 
[https://github.com/theofficialvkr/VKRdownloader/blob/main/updates.md](https://github.com/theofficialvkr/VKRdownloader/blob/main/updates.md)


# How To Install 

Step 1 - Upload zip Files ...

Step 2 - unzip file on your server / hosting file manager ..

Step 3 - it work on almost all hosting (free/paid) so don't care about requirement ...

Step 4 - Thats it !

Open Your Site And it start Working ....


# Demo : 
https://theofficialvkr.github.io/VKRdownloader/

# For Any kind of Help 


Contact me On Mail      :  <li>contactvkr@yahoo.com   </li> 
Or On Social media 
  <li>
<a href="https://instagram.com/theofficialvkr"> 
Instagram </a>
 </li> <li>
<a href="https://twitter.com/theofficialvkr"> 
Twitter </a> </li> <li>
  <a href="https://facebook.com/theofficialvkr"> 
Facebook </a> </li> <li>
  <a href="https://t.me/theofficialvkr"> 
Telegram  </a> </li> <li>


<a href="https://www.buymeacoffee.com/theofficialvkr"><img src="https://img.buymeacoffee.com/button-api/?text=Buy me a coffee&emoji=&slug=theofficialvkr&button_colour=BD5FFF&font_colour=ffffff&font_family=Cookie&outline_colour=000000&coffee_colour=FFDD00"></a>
</li> 

# At Last Remember 

i am not the Developer 👍
